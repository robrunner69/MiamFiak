package main

import "fmt"

func main() {
	i := 0
	j := -1
	for i > j {
		fmt.Println("Miam Fiak!")
		fmt.Println("Miam Fiak!")
		fmt.Println("Miam Fiak!")
		fmt.Println("Miam Fiak!")
		i++
	}
}
